<?php
if (session_status() == PHP_SESSION_NONE) session_start();
function require_login(){
    if (empty($_SESSION['user_id'])){
        header('Location: /login.php'); exit;
    }
}
function require_role($role){
    if (empty($_SESSION['role_name']) || $_SESSION['role_name'] !== $role){
        http_response_code(403); echo 'Forbidden - requires role '.$role; exit;
    }
}
function load_session_from_db($pdo){
    if (!empty($_SESSION['user_id'])){
        $stmt = $pdo->prepare('SELECT u.id, u.username, u.full_name, r.role_name FROM users u LEFT JOIN users_roles r ON u.role_id=r.id WHERE u.id=?');
        $stmt->execute([$_SESSION['user_id']]);
        $u = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($u){
            $_SESSION['username']=$u['username']; $_SESSION['full_name']=$u['full_name']; $_SESSION['role_name']=$u['role_name'];
        }
    }
}
?>