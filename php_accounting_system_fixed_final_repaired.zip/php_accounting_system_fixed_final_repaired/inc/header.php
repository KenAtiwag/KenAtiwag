<?php
if (session_status() == PHP_SESSION_NONE) session_start();
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Accounting System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/custom.css">
</head><body>
<nav class="navbar navbar-expand-lg navbar-light bg-light mb-3">
  <div class="container-fluid">
    <a class="navbar-brand" href="/index.php">AcctSys</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navmenu">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <?php if(!empty($_SESSION['user_id'])): ?>
        <li class="nav-item"><a class="nav-link" href="/dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="/journal.php">Journal</a></li>
        <li class="nav-item"><a class="nav-link" href="/ledger.php">Ledger</a></li>
        <li class="nav-item"><a class="nav-link" href="/trial_balance.php">Trial Balance</a></li>
        <li class="nav-item"><a class="nav-link" href="/reports_income.php">Income</a></li>
        <li class="nav-item"><a class="nav-link" href="/reports_balance.php">Balance</a></li>
        <li class="nav-item"><a class="nav-link" href="/accounts.php">Chart of Accounts</a></li>
        <?php if(!empty($_SESSION['role_name']) && $_SESSION['role_name']=='Admin'): ?>
        <li class="nav-item"><a class="nav-link" href="/roles.php">Roles</a></li>
        <li class="nav-item"><a class="nav-link" href="/users.php">Users</a></li>
        <li class="nav-item"><a class="nav-link" href="/admin/backup.php">Backup</a></li>
        <?php endif; ?>
        <?php endif; ?>
      </ul>
      <ul class="navbar-nav">
        <?php if(!empty($_SESSION['user_id'])): ?>
          <li class="nav-item"><span class="nav-link">Hi, <?php echo htmlentities($_SESSION['full_name'] ?? $_SESSION['username']); ?></span></li>
          <li class="nav-item"><a class="nav-link" href="/logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="/login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container">