<?php
// session.php - shared session handling and inactivity timeout
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['CREATED'])) {
    $_SESSION['CREATED'] = time();
} elseif (time() - $_SESSION['CREATED'] > 300) {
    session_regenerate_id(true);
    $_SESSION['CREATED'] = time();
}
$INACTIVITY_TIMEOUT = 1800;
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $INACTIVITY_TIMEOUT)) {
    session_unset();
    session_destroy();
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('HTTP/1.1 401 Unauthorized');
        echo json_encode(['status'=>'timeout']);
        exit;
    } else {
        header('Location: /login.php');
        exit;
    }
}
$_SESSION['LAST_ACTIVITY'] = time();
?>