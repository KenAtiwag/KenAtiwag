PHP Accounting Full Starter (Tailwind + Flowbite)
- Install: place folder in web root, visit install.php once to create DB and admin user (admin/admin), then delete install.php.
- Uses MySQL (change config.php to match DB credentials).
- Uploads stored in uploads/ folder.
- Backup script example: backup.sh
- Tables created: users, accounts, transactions, reports.


=== AUTOMATIC PATCHES APPLIED ===
- inc/session.php added (inactivity timeout 30 minutes, session regen).
- Protected pages now include session handler.
- transactions.php includes server-side upload validation (JPG/PNG, max 2MB). Uploaded path stored in POST['receipt_path'].
- admin/backup.php added to trigger backup.sh (admin-only).
Please test locally and adapt DB field names if necessary.


=== FINAL UPGRADES APPLIED ===
- transactions.php updated to use receipt path ($_POST['receipt_path']) when saving to DB. Ensure your INSERT uses this field.
- admin/restore.php added: upload a .sql file to restore the DB. The script uses DB credentials from config.php if present, otherwise set environment variables DB_USER/DB_PASS/DB_NAME or edit the file. Ensure the web server user can run mysql and has access.
- reports/export_pdf.php added: attempts to use dompdf if installed (vendor/autoload.php). If dompdf is not present, it serves printable HTML; use browser Print → Save as PDF to create PDF.

Testing notes:
- To enable true PDF export, install dompdf via composer in project root: `composer require dompdf/dompdf`.
- To allow restore, ensure `mysql` CLI is available to web server and DB credentials are correct. Restores can be dangerous; backup first.
