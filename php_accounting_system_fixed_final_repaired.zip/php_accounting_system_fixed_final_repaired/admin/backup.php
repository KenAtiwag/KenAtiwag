<?php
require_once __DIR__.'/../inc/session.php';
if (empty($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    header('HTTP/1.1 403 Forbidden'); echo 'Access denied'; exit;
}
$output=[]; $rc=0;
$script = __DIR__.'/../backup.sh';
if (!file_exists($script)) { echo 'Backup script not found.'; exit; }
exec('bash ' . escapeshellarg($script) . ' 2>&1', $output, $rc);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Backup</title></head><body>
<h1>Backup Result</h1>
<p>Status: <?php echo $rc===0? 'Success':'Failed'; ?></p>
<pre><?php foreach ($output as $line) echo htmlspecialchars($line) . "\n"; ?></pre>
<p><a href="/admin/backup.php">Run again</a> | <a href="/index.php">Dashboard</a></p>
</body></html>
