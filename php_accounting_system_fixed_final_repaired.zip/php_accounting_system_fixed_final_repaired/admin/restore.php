<?php
require_once __DIR__.'/../inc/session.php';
if (empty($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    header('HTTP/1.1 403 Forbidden'); echo 'Access denied'; exit;
}
$errors = [];
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['sqlfile'])) {
    if ($_FILES['sqlfile']['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'Upload failed with error code ' . $_FILES['sqlfile']['error'];
    } else {
        $tmp = $_FILES['sqlfile']['tmp_name'];
        $name = basename($_FILES['sqlfile']['name']);
        $dest = __DIR__ . '/../backups/' . uniqid('restore_', true) . '_' . $name;
        if (!is_dir(dirname($dest))) mkdir(dirname($dest), 0755, true);
        if (!move_uploaded_file($tmp, $dest)) {
            $errors[] = 'Failed moving uploaded file.';
        } else {
            // Attempt restore using mysql command. Ensure web server user has permission.
            // DB credentials will be read from config.php if possible.
            $dbHost = getenv('DB_HOST') ?: '';
            $dbUser = getenv('DB_USER') ?: '';
            $dbPass = getenv('DB_PASS') ?: '';
            $dbName = getenv('DB_NAME') ?: '';
            if (empty($dbUser) || empty($dbName)) {
                $errors[] = 'DB credentials not found in config.php. Edit admin/restore.php to set credentials or set environment variables DB_USER/DB_PASS/DB_NAME.';
            } else {
                $cmd = 'mysql -h ' . escapeshellarg($dbHost) . ' -u ' . escapeshellarg($dbUser) . ' ' . (!empty($dbPass)? ('-p' . escapeshellarg($dbPass)) : '') . ' ' . escapeshellarg($dbName) . ' < ' . escapeshellarg($dest) . ' 2>&1';
                exec($cmd, $output, $rc);
                if ($rc !== 0) {
                    $errors[] = 'Restore command failed. Output: ' . implode('\n', $output);
                } else {
                    $success = 'Restore completed successfully.';
                }
            }
        }
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Restore</title></head><body>
<h1>Admin Restore</h1>
<?php if (!empty($errors)) { echo '<div style="color:red"><pre>'.htmlspecialchars(implode("\n", $errors)).'</pre></div>'; } ?>
<?php if (!empty($success)) { echo '<div style="color:green">'.htmlspecialchars($success).'</div>'; } ?>
<form method="post" enctype="multipart/form-data">
<label>Upload SQL file to restore: <input type="file" name="sqlfile" accept=".sql,application/sql"></label><br><br>
<button type="submit">Restore</button>
</form>
<p><a href="/admin/backup.php">Back to Backup</a> | <a href="/index.php">Dashboard</a></p>
</body></html>
