DROP DATABASE IF EXISTS accounting_db;
CREATE DATABASE accounting_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
USE accounting_db;

-- ======================
-- USER ROLES
-- ======================
CREATE TABLE users_roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role_name VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

INSERT INTO users_roles (id, role_name) VALUES
(1,'Administrator'),
(2,'Accountant'),
(3,'Viewer');

-- ======================
-- USERS
-- ======================
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(200) NOT NULL,
  role_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (role_id) REFERENCES users_roles(id)
) ENGINE=InnoDB;

-- Admin account (admin / admin123)
INSERT INTO users (username,password,full_name,role_id) VALUES (
  'admin',
  '$2y$10$6qTQ0AvFp8ZUBKbjDg7DuOkNnNysGEKMluSleqU9jw.Cyhl725LL6',
  'System Administrator',
  1
);

-- ======================
-- ACCOUNTS (Chart of Accounts)
-- ======================
CREATE TABLE accounts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  account_code VARCHAR(50),
  account_name VARCHAR(150) NOT NULL,
  account_type ENUM('Asset','Liability','Equity','Revenue','Expense') NOT NULL,
  description TEXT
) ENGINE=InnoDB;

-- ======================
-- TRANSACTIONS
-- ======================
CREATE TABLE transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  type ENUM('income','expense') NOT NULL,
  amount DECIMAL(13,2) NOT NULL,
  account_id INT,
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES accounts(id)
) ENGINE=InnoDB;

-- ======================
-- JOURNAL ENTRIES
-- ======================
CREATE TABLE journal_entries (
  id INT AUTO_INCREMENT PRIMARY KEY,
  entry_date DATE NOT NULL,
  reference VARCHAR(100),
  description TEXT,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  posted TINYINT(1) DEFAULT 0,
  FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB;

-- ======================
-- JOURNAL ITEMS
-- ======================
CREATE TABLE journal_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  journal_id INT NOT NULL,
  account_id INT NOT NULL,
  debit DECIMAL(15,2) DEFAULT 0,
  credit DECIMAL(15,2) DEFAULT 0,
  FOREIGN KEY (journal_id) REFERENCES journal_entries(id) ON DELETE CASCADE,
  FOREIGN KEY (account_id) REFERENCES accounts(id)
) ENGINE=InnoDB;

-- ======================
-- REPORTS
-- ======================
CREATE TABLE reports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  report_name VARCHAR(150),
  report_type VARCHAR(50),
  generated_at DATETIME,
  data LONGTEXT
) ENGINE=InnoDB;

-- ======================
-- AUDIT LOGS
-- ======================
CREATE TABLE audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  action VARCHAR(200),
  details TEXT,
  ip_address VARCHAR(45),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;
