<?php
require_once __DIR__.'/../inc/session.php';
if (empty($_SESSION['user_id'])) { header('Location: /login.php'); exit; }
// parameters: from, to or month/year
$from = $_GET['from'] ?? null;
$to = $_GET['to'] ?? null;
// generate HTML for report (reuse reports.php logic minimally)
ob_start();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Report Export</title>
<style>
body{font-family: Arial, sans-serif; font-size:14px;}
table{border-collapse:collapse; width:100%;}
th,td{border:1px solid #ccc; padding:6px; text-align:left;}
h1{font-size:18px;}
</style>
</head><body>
<h1>Accounting Report</h1>
<p>Generated: <?= date('Y-m-d H:i') ?></p>
<table>
<thead><tr><th>Date</th><th>Type</th><th>Account</th><th>Description</th><th>Amount</th></tr></thead>
<tbody>
<?php
// Basic DB read - using config.php to get PDO if available
require_once __DIR__.'/../config.php';
try {
    if (!isset($pdo)) {
        // try to create PDO from config variables if present
        if (isset($db_host) && isset($db_user) && isset($db_pass) && isset($db_name)) {
            $dsn = "mysql:host={$db_host};dbname={$db_name};charset=utf8";
            }
    }
    $sql = "SELECT t.created_at, t.type, a.name as account, t.description, t.amount FROM transactions t LEFT JOIN accounts a ON a.id = t.account_id ORDER BY t.created_at DESC LIMIT 500";
    foreach ($pdo->query($sql) as $row) {
        echo '<tr><td>'.htmlspecialchars($row['created_at']).'</td><td>'.htmlspecialchars($row['type']).'</td><td>'.htmlspecialchars($row['account']).'</td><td>'.htmlspecialchars($row['description']).'</td><td>'.number_format($row['amount'],2).'</td></tr>';
    }
} catch (Exception $e) {
    echo '<tr><td colspan="5">Error reading DB: '.htmlspecialchars($e->getMessage()).'</td></tr>';
}
?>
</tbody></table>
</body></html>
<?php
$html = ob_get_clean();
// try dompdf if installed via composer
if (file_exists(__DIR__.'/../vendor/autoload.php')) {
    require_once __DIR__.'/../vendor/autoload.php';
    try {
        $dompdf = new \Dompdf\Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $dompdf->stream('report_'.date('Ymd_His').'.pdf', ['Attachment'=>1]);
        exit;
    } catch (Exception $e) {
        // fallthrough to printable HTML
    }
}
// Fallback: serve HTML with instructions to print to PDF
header('Content-Type: text/html; charset=utf-8');
echo $html;
