<?phpif (!isset($_SESSION['user_id'])) header('Location: login.php');
require 'config.php';
$month = $_GET['month'] ?? null;
$sql = "SELECT * FROM transactions";
$params = [];
if ($month) {
    $sql .= " WHERE DATE_FORMAT(created_at, '%Y-%m') = ?";
    $params[] = $month;
}
$sql .= " ORDER BY created_at ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();
?>
<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Printable Report</title>
<style>body{font-family:Arial,Helvetica,sans-serif;font-size:12px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:6px;text-align:left}h2{text-align:center}</style>
</head><body>
<h2>Transactions Report <?= $month ? ' - '.htmlspecialchars($month) : '' ?></h2>
<p>Generated: <?= date('Y-m-d H:i') ?></p>
<table><thead><tr><th>#</th><th>Date</th><th>Type</th><th>Account</th><th>Amount</th><th>Description</th></tr></thead><tbody>
<?php foreach($rows as $r): ?>
  <tr><td><?=htmlspecialchars($r['id'])?></td><td><?=htmlspecialchars($r['created_at'])?></td><td><?=htmlspecialchars($r['type'])?></td><td><?php
    if ($r['account_id']) {
        $st = $pdo->prepare('SELECT account_name FROM accounts WHERE id=?'); $st->execute([$r['account_id']]); $a = $st->fetchColumn(); echo htmlspecialchars($a);
    } else echo '';
  ?></td><td><?=number_format($r['amount'],2)?></td><td><?=htmlspecialchars($r['description'])?></td></tr>
<?php endforeach; ?>
</tbody></table>
<p style="margin-top:10px"><button onclick="window.print()">Print / Save as PDF</button></p>
</body></html>
